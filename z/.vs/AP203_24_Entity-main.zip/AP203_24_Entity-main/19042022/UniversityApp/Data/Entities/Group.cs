﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UniversityApp.Data.Entities
{
    internal class Group
    {
        public int Id { get; set; } 
        public string No { get; set; }
        public int GroupLimit { get; set; }
    }
}
