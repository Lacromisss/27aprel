﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _05042022
{
    enum Genre
    {
        Genre1,
        Genre2,
    }
}
