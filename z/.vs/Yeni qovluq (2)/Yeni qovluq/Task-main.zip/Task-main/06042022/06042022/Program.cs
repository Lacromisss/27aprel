﻿using System;

namespace _06042022
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("* --- $ --- *");
            Console.WriteLine("*  Mushvig  *");
            Console.WriteLine("*    ***    *");
            Console.WriteLine("* --- $ --- *");
        }
    }
}
