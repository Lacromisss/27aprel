﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RestaurantOrderSystem
{
    public enum Categories
    {
        Sup = 1,
        AnaYemek,
        Icki,
        Desert
    }
}
