﻿using System;

namespace _29mart
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region Task 1

            //string text = "shukurov mushvig";
            //text = text.ToCapitalize();
            //// ------------- * -------------
            //Console.WriteLine(text);
            //int[] indexes = text.GetValueIndexes('u');
            //foreach (int index in indexes)
            //{
            //    Console.WriteLine(index);
            //}
            //// ------------- * -------------
            //Console.WriteLine(text.IsContainsDigit());
            //// ------------- * -------------
            //int number = 90;
            //Console.WriteLine(number.IsEven());
            //Console.WriteLine(number.IsOdd());




            #endregion
            #region Task 2
            //string fullName;
            //do
            //{
            //    Console.WriteLine("Student Full Name Daxil Edin :");
            //    fullName = Console.ReadLine();
            //} while (!Student.CheckFullName(fullName));
            //string groupNo;
            //do
            //{
            //    Console.WriteLine("Student groupNo Daxil Edin :");
            //    groupNo = Console.ReadLine();
            //} while (!Student.CheckGroupNo(groupNo));

            //Console.WriteLine("Student Age Daxil Edin :");
            //int Age = int.Parse(Console.ReadLine());


            //Student student = new Student(fullName, groupNo, Age);


            //Console.WriteLine(student.FullName);
            //Console.WriteLine(student.Age);
            //Console.WriteLine(student.GroupNo);
            #endregion
        }
    }
}
