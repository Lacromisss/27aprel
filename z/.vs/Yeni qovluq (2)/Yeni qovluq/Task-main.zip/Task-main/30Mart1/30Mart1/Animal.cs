﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _30Mart1
{
    internal class Animal
    {
        public string Name { get; set; }
        public bool Gender { get; set; }
        public int Age { get; set; }

    }
}
