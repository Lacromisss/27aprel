﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _31mart
{
    enum Groups
    {
        Programming,Design,System
    }
}
