﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Modelss
{
    public enum Catagory
    {
        Sup,
        Anayemek,
        Desert,
        Icki
    }
}