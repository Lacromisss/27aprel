﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Modelss
{
    internal class OrderItem
    {
        public int MenuItem { get; set; }
        public int Count { get; set; }
    }
}